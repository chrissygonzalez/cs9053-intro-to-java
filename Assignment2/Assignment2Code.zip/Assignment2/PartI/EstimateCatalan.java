
public class  EstimateCatalan {

	public static final double CATALAN =  0.915965594177219015054603514932384110774;
	
	public static double estimateCatalan() {
		
		return -1;
	}
	
	public static void main(String[] args) {
		
	}
}
