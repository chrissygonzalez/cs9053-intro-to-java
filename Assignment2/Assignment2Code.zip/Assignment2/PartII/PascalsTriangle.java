
public class PascalsTriangle {

	public static int[][] createPascalTriangle(int rows) {
		
		return null;
	}
	
	public static void main(String[] args) {
		
		int[][] triangle = createPascalTriangle(1);
		
		// iterate over the triangle variable to print out
		// the pascal's triangle.

	}

}
