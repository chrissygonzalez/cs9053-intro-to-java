
public class DumbPasswords {

	public static void printDumbPasswords(int m, int n) {
		
	}
	
	public static void main(String[] args) {
		printDumbPasswords(4,2);
		
	}
}
