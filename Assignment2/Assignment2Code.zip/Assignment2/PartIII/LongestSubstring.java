
public class LongestSubstring {

	public static String longestSubstring(String s) {
	
		return null;
	}
	
	public static void main(String[] args) {
		

	}

}
