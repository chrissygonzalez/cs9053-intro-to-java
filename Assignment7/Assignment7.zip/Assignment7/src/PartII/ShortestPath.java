package PartII;

import java.util.List;

public class ShortestPath {

	// you can use this class to just have static methods that takes
	// an adjacency list, a start node (A), and an end node (Z).
	// Use any collection classes you want to create the adjacency lists
	// Use any classes you choose to define edges or nodes that you wish.
	// There's no single "correct" answer to these questions
	
	public static List getShortestPath() { 
		// graph, start node, end node should be the arguments
		// return a list of nodes in the array list, and from there the
		// caller should be able to calculate the path distance
		// alternately you could  return a class that contains
		// the list of nodes in the shortest path and the length of that 
		// path
		return null;
	}
}
