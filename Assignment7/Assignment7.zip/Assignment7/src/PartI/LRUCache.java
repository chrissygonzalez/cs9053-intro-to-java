package PartI;

public class LRUCache<V> {

	
	public LRUCache(int capacity) {
		
	}
	public void put(Integer k, V value) {
		
	}
	
	public V get(Integer k) {
		return null;
	}
	
	
}
