
public class Party {

}
