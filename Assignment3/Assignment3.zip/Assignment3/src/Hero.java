
public class Hero {

}
