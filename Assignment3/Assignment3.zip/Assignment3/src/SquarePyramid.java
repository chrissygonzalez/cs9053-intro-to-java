
public class SquarePyramid {

}
