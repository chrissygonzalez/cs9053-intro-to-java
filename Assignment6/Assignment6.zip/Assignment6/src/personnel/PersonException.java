package personnel;

public class PersonException extends RuntimeException {

	public PersonException() {
		
	}
	
	public PersonException(String msg) {
		super(msg);
	}
}
