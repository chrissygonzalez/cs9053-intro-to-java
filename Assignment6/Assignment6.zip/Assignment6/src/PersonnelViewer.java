import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;
import personnel.*;

public class PersonnelViewer extends JFrame {

	JFileChooser jFileChooser;
	
	
	public PersonnelViewer() {

		jFileChooser = new JFileChooser(".");
		
	}
	
	
	class OpenFileListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			int returnVal = jFileChooser.showOpenDialog(getParent());
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				try {
					System.out.println("You chose to open this file: " + jFileChooser.getSelectedFile().getAbsolutePath());

					InputStream in = new FileInputStream(jFileChooser.getSelectedFile().getAbsolutePath());

				} catch (IOException error){
					error.printStackTrace();
				}
			}
		}
	}
	public static void main(String[] args) {
		PersonnelViewer pv = new PersonnelViewer();
	}

	
	
}
