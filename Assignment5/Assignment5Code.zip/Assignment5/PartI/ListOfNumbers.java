import java.io.*;
import java.util.List;
import java.util.ArrayList;
 
public class ListOfNumbers {
	
    private ArrayList rdfTripleList;
    private String fileName;
 
    
    public ArrayList getRdfTripleList() {
    	return this.rdfTripleList;
    }
    
    public void createList() {
    	for (int i = 0 ; i< 100 ; i++) {
    		Integer number1 = (int) (Math.random()*10000);
    		Integer number2 = (int) (Math.random()*10000);
    		Integer number3 = (int) (Math.random()*10000);
    		// create a new  list with RDFTriple objects
    		// of three numbers.
    	}
    }
    

    public ListOfNumbers (String fileName) {
    	this();
    	this.fileName = fileName;	
    }
    
    public void readList() {
    	// create an ArrayList of RDFTriples 
    }
    
    public void writeList(String outfile) {
        
    }
    
    
    public static void main(String[] args) {
    	ListOfNumbers listOfNumbers = new ListOfNumbers("numberfile.txt");
    	listOfNumbers.readList();
    	listOfNumbers.createList();
    	listOfNumbers.writeList("rdfoutput.txt");
    }

}
