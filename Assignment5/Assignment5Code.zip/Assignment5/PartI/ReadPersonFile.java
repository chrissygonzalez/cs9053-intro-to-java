import java.io.*;
import java.util.ArrayList;

import personnel.*;

/* your tasks:
 * create a class called PersonException
 * createPerson should throw a PersonException
 * in main(), you should catch the PersonException
 * 
 */
public class ReadPersonFile {

	public static Person createPerson(String shape) {
		

		return null;
	}
	
	public static void main(String[] args) {
		ArrayList<Person> personList = new ArrayList<Person>();
		File f = new File("personnel.txt");
		
		String inString = null;
		
		/* create a loop to read the file line-by-line */
		
		try {
			
			Person person = createPerson(inString);
		} catch (/* your exception */ ) {
			System.err.println("Cannot create Person: " + inString);
		}

		System.out.println(personList);
		
	}
}
