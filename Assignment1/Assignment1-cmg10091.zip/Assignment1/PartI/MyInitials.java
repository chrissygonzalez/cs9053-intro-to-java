
public class MyInitials {

	public static void main(String[] args) {
		System.out.println(" CCC   M   M   GGG ");
		System.out.println("C   C  MM MM  G   G ");
		System.out.println("C      MM MM  G     ");
		System.out.println("C      M M M  GGGGG ");
		System.out.println("C      M   M  G   G ");
		System.out.println("C   C  M   M  G   G ");
		System.out.println(" CCC   M   M   GGG ");
	}
}
