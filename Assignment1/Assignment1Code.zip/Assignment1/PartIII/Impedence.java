public class Impedence {

	public static double calculateImpedence() {

		double pi = Math.PI;
		return -1;
	}
	
	public static void main(String[] args) {
		
		
		double totalImpedence = calculateImpedence();
		System.out.println("The total impedence in Ohms is: ");

	}
}