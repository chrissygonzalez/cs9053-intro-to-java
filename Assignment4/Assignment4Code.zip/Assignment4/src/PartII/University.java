package PartII;

public class University {

	
	public void registerStudent() {
		
	}
	
	public boolean deregisterStudent() {
		
		return false;
	}
	
	public boolean studentRegistered() {
		return false;
	}
	
	public void printAllStudents() {
		
	}
}
